<?php 

add_action('woocommerce_single_product_summary', 'moc_wcf_combo_template', 100);

function moc_wcf_combo_template() {
    global $post;
    
    // get data combo
    $list = array();
    if(!empty(get_post_meta(get_the_ID(), '_moc_wcf', true ))) {
        $list = get_post_meta(get_the_ID(), '_moc_wcf', true );
    }
    
    $list = array_unique($list);    
    array_unshift($list, $post->ID);    
    $count = count($list);
    $total = 0;
    if($count >= 2) { ?>
        <div id="moc_wcf">
            <?php echo wp_kses_post(moc_plugin_get_option('moc_wcf_text_before')); ?>
            <div class="head">
                <?php echo esc_html(moc_plugin_get_option('_moc_wcf_title', esc_attr__( 'Combo Offers', 'dgm-wcf' )));?>
            </div>
            <div class="body">
                <div class="list">
                    <?php foreach ($list as $key => $value) {
                        $product = wc_get_product($value); 
                        $total = $total + $product->get_price(); ?>
                            <div class="item active">
                                <div class="checkbox-wrap">
                                    <label class="checkbox">
                                        <input type="checkbox" class="combo-checkbox current" value="<?php echo esc_attr( $value ); ?>" name="moc_wcf[]" data-price="<?php echo esc_attr($product->get_price()); ?>" data-pid="<?php echo esc_attr($value); ?>" checked> 
                                        <span class="ico"></span>
                                    </label>
                                </div>
                                <div class="image">
                                    <a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" title="<?php echo esc_attr( $product->get_name() ); ?>">
                                        <?php echo get_the_post_thumbnail( $product->get_id(), 'woocommerce_gallery_thumbnail' ); ?>
                                    </a>
                                </div>
                                <div class="name">
                                    <?php if($key == 0) { echo '<b>' . esc_attr(moc_plugin_get_option('_moc_wcf_current', esc_attr__( 'Current item:', 'dgm-wcf' ))) . '</b>'; } ?>
                                    <a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" title="<?php echo esc_attr( $product->get_name() ); ?>">
                                        <?php echo esc_attr( $product->get_name() ); ?>
                                    </a>
                                </div>
                                <div class="price">
                                    <?php echo wc_price($product->get_price()); ?>
                                </div>
                            </div>
                        <?php
                    } ?>
                </div>
                <div class="footer">
                    <p>
                        <?php echo esc_html(moc_plugin_get_option('_moc_wcf_total', esc_attr__( 'Total:', 'dgm-wcf' )));?>
                        <span class="total"><?php echo wp_kses_post(wc_price($total)); ?></span>
                    </p>
                    <div class="redirect">                        
                        <button class="moc_add_combo" type="button">
                            <?php echo wp_kses_post(str_replace('%count%', '<span class="number">'.$count.'</span>', moc_plugin_get_option('_moc_wcf_text'))); ?>
                        </button>
                    </div>
                </div>
            </div>
            <?php echo wp_kses_post(moc_plugin_get_option('moc_wcf_text_after')); ?>
        </div>
    <?php }
}