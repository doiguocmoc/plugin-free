<?php 

add_action( 'wp_ajax_moc_wcf', 'moc_wcf_init_ajax' );
add_action( 'wp_ajax_nopriv_moc_wcf', 'moc_wcf_init_ajax' );
function moc_wcf_init_ajax() {
    $items = (isset($_POST['items'])) ? array_map( 'esc_attr', $_POST['items'] ) : array();
    foreach ($items as $key => $value) {
        WC()->cart->add_to_cart( $value );
    }
    echo '<a href="'.esc_url(wc_get_checkout_url()).'">'.esc_attr(moc_plugin_get_option('_moc_wcf_success', esc_attr__( 'Added combo successfully! Checkout now!', 'dgm-wcf' ))).'</a>';
    die();
}