<?php 

if(!function_exists('moc_plugin_admin_menu')) {    
    function moc_plugin_admin_menu() {
        add_menu_page (
            esc_attr__( 'MOC Plugins', 'moc-wcf' ),
            esc_attr__( 'MOC Plugins', 'moc-wcf' ),
            'manage_options',
            'moc_plugins',
            'moc_plugin_menu_template',
            '',
            '65'
        );
    }
    add_action('admin_menu', 'moc_plugin_admin_menu', 1);
}

if(!function_exists('moc_plugin_menu_template')) {    
    function moc_plugin_menu_template() { ?>
        <div class="wrap">    
            <h1><?php _e('MOC List Plugin Active', 'moc-wcf'); ?></h1>
            <div class="plugin-content">                
                <div class="list-plugin-active">
                    <?php do_action( 'moc_plugin_admin_active' ); ?>                    
                </div>
            </div>
        </div>
    <?php }
}