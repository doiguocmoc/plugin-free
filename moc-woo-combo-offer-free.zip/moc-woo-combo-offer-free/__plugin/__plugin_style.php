<?php 

if(!function_exists('moc_plugin_admin_style')) {  
    function moc_plugin_admin_style( $hook ) {
        wp_register_style( 'moc-plugin-admin-style', MOC_WCF_DIR . 'css/__layout.css', 'all' );
        wp_enqueue_style( 'moc-plugin-admin-style' );
    }
    add_action( 'admin_enqueue_scripts', 'moc_plugin_admin_style' );
}