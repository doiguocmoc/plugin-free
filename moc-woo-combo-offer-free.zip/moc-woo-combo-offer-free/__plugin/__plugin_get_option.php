<?php 

if(!function_exists('moc_plugin_get_option')) { 
    function moc_plugin_get_option( $key, $default = null ) {
        $str = $default;
        if(!empty(get_option($key))) {
            $str = get_option($key);
        }
        return trim($str);
    }
}