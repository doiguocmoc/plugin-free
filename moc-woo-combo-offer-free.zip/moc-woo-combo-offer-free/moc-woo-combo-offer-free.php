<?php
/**
* Plugin Name: MOC Woo Combo Offer Free
* Description: Plugin hỗ trợ bạn tạo ra combo các sản phẩm thường bán cùng nhau cho website sử dụng WooCommerce.
* Version: 1.0.0
* Author: Mộc
* Author URI: https://www.facebook.com/letuan.dgm
* License: GPLv2 or later
* Text-domain: moc-wcf
* Domain Path: /language/
**/

defined( 'ABSPATH' ) || die;

define( 'MOC_WCF_DIR', plugin_dir_url( __FILE__ ));

// load MOC Plugins 
foreach (glob(dirname(__FILE__) . "/__plugin/*.php") as $file) {
	include $file;
}

// Load core
foreach (glob(dirname(__FILE__) . "/core/*.php") as $file) {
	include $file;
}

// load admin core 
if(is_admin()) {    
    foreach (glob(dirname(__FILE__) . "/admin/*.php") as $file) {
    	include $file;
    }
}


// Plugin js
function moc_wcf_style() {
    wp_register_style( 'moc-wcf-style', MOC_WCF_DIR . 'css/style.css', 'all' );
    wp_enqueue_style( 'moc-wcf-style' );
    if(is_product()) {
        wp_enqueue_script( 'jquery-core' );
        wp_enqueue_script( 'moc-wcf-js', MOC_WCF_DIR . 'js/moc-wcf.min.js', array(), 'all', true );
        wp_localize_script(
            'moc-wcf-js',
            'moc_wcf',
            array(
                'ajax'      => admin_url('admin-ajax.php'),
				'nonce'		=> wp_create_nonce( 'moc_wcf' ),
                'cr'        => get_woocommerce_currency_symbol(get_option( 'woocommerce_currency' )),
                'cr_p'      => get_option( 'woocommerce_currency_pos' ),
                'ts'        => get_option( 'woocommerce_price_thousand_sep' ),
                'ds'        => get_option( 'woocommerce_price_decimal_sep' ),
                'nod'       => get_option( 'woocommerce_price_num_decimals' ),
            )
        );        
    } 
}
add_action( 'wp_enqueue_scripts', 'moc_wcf_style', 9999 );