<?php 

add_action('publish_product', 'moc_wcf_add_product', 10, 1);
function moc_wcf_add_product($post_id ) {
    $list_added = array();
    if(!empty(get_post_meta( $post_id, '_moc_wcf_added', true ))) {
        $list_added = get_post_meta( $post_id, '_moc_wcf_added', true );
    }        
    foreach ($list_added as $key => $value) {
        $list_combo = array();
        if(!empty(get_post_meta( $value, '_moc_wcf', true ))) {
            $list_combo = get_post_meta( $value, '_moc_wcf', true );
        }        
        $list_combo[$post_id] = $post_id;    
        $list_combo = array_unique($list_combo);  
    	update_post_meta( $value, '_moc_wcf', $list_combo );
    }
}