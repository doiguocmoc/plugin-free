<?php 

// create product tab
function moc_wcf_product_tab( $product_data_tabs ) {
    $product_data_tabs['moc_wcf'] = array(
        'label'         => __( 'Product Combo', 'moc-wcf' ),
        'target'        => 'moc_wcf_product_data',
        'class'         => array( 'moc_wcf' ),
    );
    return $product_data_tabs;
}
add_filter( 'woocommerce_product_data_tabs', 'moc_wcf_product_tab' );


// product tab content
function moc_wcf_product_panels(){ ?>
	<div id="moc_wcf_product_data" class="panel woocommerce_options_panel hidden">
        <div class="options_group">
        	<p class="form-field menu_order_field">
        		<label><?php _e( 'List product in combo', 'moc-wcf' ); ?></label>
                <?php 
                    $items = array();
                    if(!empty(get_post_meta(get_the_ID(), '_moc_wcf', true ))) {
                        $items = get_post_meta(get_the_ID(), '_moc_wcf', true );
                    }
                                        
                    $items = array_values(array_unique($items));
                    for ($i=0; $i < 2 ; $i++) { 
                        $value = null;
                        if(isset($items[$i])) {
                            $value = $items[$i];
                        }
                    ?>
                        <input class="short" type="number" name="_moc_wcf[]" value="<?php echo esc_attr( $value ) ?>" placeholder="<?php esc_attr_e( 'ID Product ', 'moc-wcf' ); echo esc_attr($i + 1); ?>" style="width: 100%;margin-bottom: 10px;"/>
                    <?php }
                ?>
            </p>
        </div>
	</div> 
<?php }
add_action( 'woocommerce_product_data_panels', 'moc_wcf_product_panels' );


// save combo
function moc_wcf_save_fields( $id, $post ){
    $list_items = array();
    
    $items = (isset($_POST['_moc_wcf'])) ? array_map( 'esc_attr', $_POST['_moc_wcf'] ) : array();    
    $items = array_unique($items);
    
    foreach ($items as $key => $value) {
        $list_items[$value] = $value;
        $list_added = array();
        if(empty(get_post_meta( $value, '_moc_wcf_added', true ))) {
            $list_added = get_post_meta( $value, '_moc_wcf_added', true );
        }
        $list_added[$id] = $id;
        $list_added = array_unique($list_added);
    	update_post_meta( $value, '_moc_wcf_added', $list_added );
    }        
    
	update_post_meta( $id, '_moc_wcf', $list_items );
}
add_action( 'woocommerce_process_product_meta', 'moc_wcf_save_fields', 10, 2 );