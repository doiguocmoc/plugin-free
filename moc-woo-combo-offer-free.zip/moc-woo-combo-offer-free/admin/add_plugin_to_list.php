<?php 

function moc_wcf_add_admin_list() { ?>
    <div class="item">
        <div class="content">  
            <div class="thumbnail">
                <img src="<?php echo esc_url( MOC_WCF_DIR . '/images/screenshot.png' ); ?>">
            </div>          
            <div class="title">
                <h4><?php esc_attr_e( 'MOC WooCommerce Combo Offer', 'moc-wcf' ); ?></h4>
            </div>
            <div class="footer">
                <div class="left">
                    <?php esc_attr_e( 'Free Version', 'moc-wcf' ); ?>
                </div>
                <div class="right">
                    <a class="button button-primary" href="<?php echo esc_url(admin_url( 'admin.php?page=moc_wcf_settings' )); ?>"><?php esc_attr_e( 'Settings', 'moc-wcf' ); ?></a>
                </div>
            </div>
        </div>
    </div>
<?php }
add_action('moc_plugin_admin_active', 'moc_wcf_add_admin_list');