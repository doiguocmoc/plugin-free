<?php 

add_action('trash_product', 'moc_wcf_remove_product', 10, 1);
add_action('pending_product', 'moc_wcf_remove_product', 10, 1);
add_action('draft_product', 'moc_wcf_remove_product', 10, 1);
add_action('before_delete_post', 'moc_wcf_remove_product', 10, 1);
function moc_wcf_remove_product( $post_id ) {
    $list_added = get_post_meta( $post_id, '_moc_wcf_added', true );
    if(empty($list_added)) {
        $list_added = array();
    }        
    foreach ($list_added as $key => $value) {
        $list_combo = get_post_meta( $value, '_moc_wcf', true );
        unset($list_combo[$post_id]);            
    	update_post_meta( $value, '_moc_wcf', $list_combo );
    }
}