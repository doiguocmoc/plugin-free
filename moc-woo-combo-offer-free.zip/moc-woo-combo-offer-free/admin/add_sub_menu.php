<?php 

if(!function_exists('dgm_wcf_create_menu')){
    function dgm_wcf_create_menu() {        
        add_submenu_page(
            'moc_plugins',
            __('WooCommerce Combo Offer', 'dgm-wcf'),
            __('WooCommerce Combo Offer', 'dgm-wcf'),
            'manage_options',
            'moc_wcf_settings',
            'moc_wcf_settings_template'
        ); 
    }
    
    add_action('admin_menu', 'dgm_wcf_create_menu', 2);
}