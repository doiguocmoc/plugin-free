<?php

add_action( 'admin_init', 'moc_wcf_register_settings' );
add_action( 'rest_api_init', 'moc_wcf_register_settings' );
function moc_wcf_register_settings(){    
    register_setting( 
        '_moc_wcf', 
        '_moc_wcf_title',
        array(
            'type'                  => 'string',
            'sanitize_callback'     => 'sanitize_text_field',
            'default'               => esc_attr__( 'Combo Offer', 'moc-wcf' ),
        )
    );
    register_setting( 
        '_moc_wcf', 
        '_moc_wcf_text',
        array(
            'type'                  => 'string',
            'sanitize_callback'     => 'sanitize_text_field',
            'default'               => esc_attr__( 'Add %count% product to cart', 'dgm-wcf' ),
        )
    
    );
    register_setting( 
        '_moc_wcf', 
        '_moc_wcf_current',
        array(
            'type'                  => 'string',
            'sanitize_callback'     => 'sanitize_text_field',
            'default'               => esc_attr__( 'Current item:', 'dgm-wcf' ),
        )    
    );
    register_setting( 
        '_moc_wcf', 
        '_moc_wcf_total',
        array(
            'type'                  => 'string',
            'sanitize_callback'     => 'sanitize_text_field',
            'default'               => esc_attr__( 'Total:', 'dgm-wcf' ),
        )    
    );
    register_setting( 
        '_moc_wcf', 
        '_moc_wcf_success',
        array(
            'type'                  => 'string',
            'sanitize_callback'     => 'sanitize_text_field',
            'default'               => esc_attr__( 'Added combo successfully! Checkout now!', 'dgm-wcf' ),
        )    
    );
}


function moc_wcf_settings_template() { ?>
    <?php settings_errors(); ?>
    <div class="wrap">    
        <h1><?php esc_attr_e('MOC WooCoomerce Combo Offer Settings', 'dgm-wcf'); ?></h1>
        <form method="post" action="options.php" style="max-width:100%">        
            <?php settings_fields( '_moc_wcf' ); ?>       
            <table class="form-table">
                <tbody>       
                    <tr>
                        <th scope="row">
                            <label for="_moc_wcf_title"><?php esc_attr_e('Heading', 'dgm-wcf'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="_moc_wcf_title" id="_moc_wcf_title" value="<?php echo esc_attr(moc_plugin_get_option('_moc_wcf_title', esc_attr__( 'Combo Offers', 'dgm-wcf' )));?>" class="regular-text">
                        </td>
                    </tr>                    
                    <tr>
                        <th scope="row">
                            <label for="_moc_wcf_text"><?php esc_attr_e('Text add product button', 'dgm-wcf'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="_moc_wcf_text" id="_moc_wcf_text" value="<?php echo esc_attr(moc_plugin_get_option('_moc_wcf_text', esc_attr__( 'Add %count% product to cart', 'dgm-wcf' )));?>" class="regular-text">
                            <p class="description"><code><?php esc_attr_e('%count%', 'dgm-wcf'); ?></code> <?php esc_attr_e('Number product in combo', 'dgm-wcf'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="_moc_wcf_current"><?php esc_attr_e('Current Item', 'dgm-wcf'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="_moc_wcf_current" id="_moc_wcf_current" value="<?php echo esc_attr(moc_plugin_get_option('_moc_wcf_current', esc_attr__( 'Current item:', 'dgm-wcf' )));?>" class="regular-text">
                        </td>
                    </tr>  
                    <tr>
                        <th scope="row">
                            <label for="_moc_wcf_total"><?php esc_attr_e('Total', 'dgm-wcf'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="_moc_wcf_total" id="_moc_wcf_total" value="<?php echo esc_attr(moc_plugin_get_option('_moc_wcf_total', esc_attr__( 'Total:', 'dgm-wcf' )));?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="_moc_wcf_success"><?php esc_attr_e('Add to cart complete', 'dgm-wcf'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="_moc_wcf_success" id="_moc_wcf_success" value="<?php echo esc_attr(moc_plugin_get_option('_moc_wcf_success', esc_attr__( 'Added combo successfully! Checkout now!', 'dgm-wcf' )));?>" class="regular-text">
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
<?php }