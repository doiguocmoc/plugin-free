=== MOC Woo Combo Offer Free ===
Contributors: doiguocmoc
Tags: woocommerce, product combo, combo offer
Donate link: https://www.paypal.me/doiguocmoc/5
Requires at least: 5.0.0
Tested up to: 5.4.1
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin hỗ trợ bạn tạo ra combo các sản phẩm thường bán cùng nhau cho website sử dụng WooCommerce. Giúp thúc đẩy tăng trưởng doanh số cho cửa hàng của bạn.


== Mô tả ==

Plugin hỗ trợ bạn tạo ra combo các sản phẩm thường bán cùng nhau cho website sử dụng WooCommerce. Giúp thúc đẩy tăng trưởng doanh số cho cửa hàng của bạn.


== Tính năng ==

* Dễ dàng thêm sản phẩm vào combo chỉ bằng ID
* Thêm tối đa 2 sản phẩm vào combo của bạn
* Người dùng dễ dàng tùy chọn những sản phẩm trong combo để mua


== Cài đặt ==
1. Upload `/moc-woo-combo-offer-free/` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. Go to `MOC Plugins > WooCoomerce Combo Offer` to configurate it.

== Changelog ==

= 1.0.0 =
* Create plugin