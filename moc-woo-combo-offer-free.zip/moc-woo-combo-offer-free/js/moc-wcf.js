function moc_number_format(number) {
    if (number == null || !isFinite(number)) {
        throw new TypeError("number is not valid");
    }
        
    decimals = moc_wcf.nod;
    dec_point = moc_wcf.ds;
    thousands_point = moc_wcf.ts;
    number = parseFloat(number).toFixed(decimals);
    number = number.replace(".", dec_point);
    var splitNum = number.split(dec_point);
    splitNum[0] = splitNum[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousands_point);
    number = splitNum.join(dec_point);
    
    if (moc_wcf.cr_p == 'left') {
        return moc_wcf.cr + number;
    } else if (moc_wcf.cr_p == 'left_space') {
        return moc_wcf.cr + ' ' + number;        
    } else if (moc_wcf.cr_p == 'right') {
        return number + moc_wcf.cr;    
        
    } else if (moc_wcf.cr_p == 'right_space') {
        return number + ' ' + moc_wcf.cr;            
    }    
}

jQuery(document).ready(function($) { 
    $('#moc_wcf .item .checkbox .ico').click(function(e) {
        $(this).parent().parent().parent().toggleClass('active');
        var size = 0;
        var total = 0;
        $('#moc_wcf .item.active input[name="moc_wcf[]"]').each(function() {
            size = size + 1;
            total = total + $(this).data('price');
        });
        $('#moc_wcf .footer .number').html(size);
        $('#moc_wcf .footer .total').html(moc_number_format(total));
        if(size == 0) {
            $('#moc_wcf .footer .moc_add_combo').hide();
        } else {
            $('#moc_wcf .footer .moc_add_combo').show();
        }
    });
    
    $('.moc_add_combo').click(function(e){
        var items = [];
        $('#moc_wcf .item.active input[name="moc_wcf[]"]').each(function() {
            items.push($(this).data('pid'));
        });
        $.ajax({
            type : "post",
            dataType : "html",
            url : moc_wcf.ajax,
            data : {
                _ajax_nonce: moc_wcf.nonce,
                action: "moc_wcf",
                items: items
            },
            context: this,
            success: function(response) {
                $('#moc_wcf .footer .redirect').html(response);
            },
        });
    });
});